import Carousel from './modules/carousel.js'
import {slideDown, slideUp} from './modules/animation'

document.querySelector('.nav__burger').addEventListener('click', function () {
  document.querySelector('.nav__menu').classList.toggle('is-active')
  document.querySelector('.nav__burger').classList.toggle('is-active')
})

const slider = document.querySelector('.js-slider')
if (slider) {
  new Carousel(slider, {
    infinite: true
  })
}

const contact = document.querySelector('#bien-contact')
if (contact) {
  contact.addEventListener('click', function () {
    slideUp(document.querySelector('#bien-actions'))
    slideDown(document.querySelector('#bien-form'))
  })
}